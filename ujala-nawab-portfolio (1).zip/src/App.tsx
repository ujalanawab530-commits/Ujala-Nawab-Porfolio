/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, useScroll, useSpring, useInView, AnimatePresence } from "motion/react";
import { 
  ArrowRight, 
  Cpu, 
  Linkedin, 
  MousePointer2, 
  Battery,
  Maximize,
  Check,
  Copy
} from "lucide-react";
import React, { useEffect, useState } from "react";

const SectionLabel = ({ children }: { children: React.ReactNode }) => (
  <motion.div 
    initial={{ opacity: 0, x: -10 }}
    whileInView={{ opacity: 1, x: 0 }}
    transition={{ duration: 0.8 }}
    className="flex items-center gap-4 mb-12"
  >
    <div className="w-12 h-px bg-accent/30" />
    <span className="text-[10px] font-mono font-black tracking-[0.4em] uppercase text-accent">
      {children}
    </span>
  </motion.div>
);

const RevealText = ({ children, className = "" }: { children: React.ReactNode, className?: string }) => {
  return (
    <div className={`overflow-hidden ${className}`}>
      <motion.div
        initial={{ y: "100%" }}
        whileInView={{ y: 0 }}
        viewport={{ once: true, margin: "-10%" }}
        transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
      >
        {children}
      </motion.div>
    </div>
  );
};

export default function App() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [showEmail, setShowEmail] = useState(false);
  const [copied, setCopied] = useState(false);
  const { scrollYProgress } = useScroll();

  const handleCopy = () => {
    navigator.clipboard.writeText("ujalanawab530@gmail.com");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <div className="relative min-h-screen">
      {/* Mesh Background */}
      <div className="mesh-bg">
        <div className="mesh-blob-1" />
        <div className="mesh-blob-2" />
        <div className="mesh-blob-3" />
      </div>

      {/* Floating Toolbar Overlay (Design Context) */}
      <motion.div 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="fixed top-6 left-1/2 -translate-x-1/2 px-6 py-2 bg-black/40 backdrop-blur-md rounded-full border border-white/10 flex items-center gap-6 text-[11px] text-slate-400 z-50 shadow-2xl"
      >
        <div className="flex items-center gap-2 pr-6 border-r border-white/10">
          <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
          <span className="text-white font-medium">Editor Mode</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-accent">Design Active</span>
          <span className="opacity-40">|</span>
          <span>MMXXVI Build</span>
        </div>
      </motion.div>

      {/* Custom Cursor */}
      <motion.div 
        className="fixed top-0 left-0 w-8 h-8 rounded-full border border-accent pointer-events-none z-[100] mix-blend-difference hidden md:block"
        animate={{ x: mousePos.x - 16, y: mousePos.y - 16 }}
        transition={{ type: "spring", stiffness: 500, damping: 28, mass: 0.5 }}
      />

      {/* Progress Bar */}
      <motion.div className="fixed top-0 left-0 right-0 h-[2px] bg-accent origin-left z-[110]" style={{ scaleX }} />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center py-20 px-6 md:px-12 lg:px-24 overflow-hidden">
        {/* Subtle Scan Lines / Glitch Overlay */}
        <div className="absolute inset-0 glitch-overlay opacity-30 z-0" />
        
        <div className="max-w-7xl w-full mx-auto relative z-10">
          <div className="flex flex-col gap-12 lg:gap-0 relative">
            
            {/* Top Meta Data Label */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.8 }}
              className="absolute top-0 left-0 hidden lg:flex items-center gap-4 text-[10px] font-mono tracking-[0.4em] text-slate-500 uppercase"
            >
              <div className="w-8 h-px bg-slate-800" />
              <span>Available for 2026 Projects</span>
            </motion.div>

            {/* Main Headline Group */}
            <div className="relative pt-20">
              <div className="flex flex-col">
                <div className="overflow-hidden">
                  <motion.h1 
                    initial={{ y: "130%" }}
                    animate={{ y: 0 }}
                    transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
                    className="font-sans text-[18vw] lg:text-[14vw] font-black tracking-[-0.04em] leading-[0.8] text-white uppercase select-none pointer-events-none"
                  >
                    Ujala
                  </motion.h1>
                </div>
                
                <div className="flex items-center gap-12 ml-[10vw]">
                  <div className="hidden lg:block overflow-hidden">
                    <motion.div
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: 1 }}
                      transition={{ duration: 1.5, ease: "circOut", delay: 0.5 }}
                      className="w-[20vw] h-px bg-white/10 origin-left"
                    />
                  </div>
                  <div className="overflow-hidden">
                    <motion.h1 
                      initial={{ y: "130%" }}
                      animate={{ y: 0 }}
                      transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1], delay: 0.4 }}
                      className="font-sans text-[18vw] lg:text-[14vw] font-black tracking-[-0.04em] leading-[0.8] text-transparent bg-clip-text bg-gradient-to-r from-accent via-accent-purple to-accent uppercase select-none pointer-events-none"
                    >
                      Nawab
                    </motion.h1>
                  </div>
                </div>

                {/* Subtitle */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 1, delay: 0.6 }}
                  className="mt-6 flex items-center gap-4"
                >
                  <div className="w-12 h-px bg-accent/30" />
                  <span className="text-[14px] md:text-[18px] font-mono font-black tracking-[0.5em] uppercase text-accent/80">
                    SEO and AEO content strategist
                  </span>
                </motion.div>
              </div>
            </div>

            {/* Bottom Section - Tagline & CTA */}
            <div className="flex flex-col lg:flex-row lg:items-end justify-between mt-24 gap-12 lg:gap-0">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, delay: 0.8 }}
                className="max-w-md"
              >
                <p className="text-lg md:text-xl text-slate-400 font-light leading-relaxed mb-8" suppressContentEditableWarning contentEditable>
                  Professional creative developer/designer building high-end digital experiences where strategy meets storytelling.
                </p>
                <div className="flex items-center gap-6">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex flex-col gap-2 group"
                  >
                    <span className="text-[10px] font-black uppercase tracking-[0.3em] text-accent/60 group-hover:text-accent transition-all">Click here to check my work →</span>
                    <div className="h-[2px] w-0 bg-accent group-hover:w-full transition-all duration-500" />
                  </motion.button>
                </div>
              </motion.div>

              {/* Stats Box */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1, delay: 1 }}
                className="flex gap-16 lg:gap-24"
              >
                {[
                  { label: "Experience", val: "10+ Months" },
                  { label: "Projects", val: "24+" }
                ].map((stat, i) => (
                  <div key={i} className="flex flex-col">
                    <span className="text-3xl font-black text-white mb-2" suppressContentEditableWarning contentEditable>{stat.val}</span>
                    <span className="text-[10px] uppercase tracking-[0.3em] text-slate-600 font-bold">{stat.label}</span>
                  </div>
                ))}
              </motion.div>
            </div>
          </div>
        </div>
        
        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-slate-500"
        >
          <MousePointer2 className="w-5 h-5 rotate-180" />
        </motion.div>
      </section>

      {/* About Section */}
      <section className="py-40 px-6 md:px-12 lg:px-24">
        <div className="max-w-7xl w-full mx-auto">
          <SectionLabel>Core Philosophy</SectionLabel>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            <RevealText>
              <h2 className="text-4xl md:text-7xl font-black tracking-tighter text-white uppercase leading-[0.9] mb-12">
                Crafting the<br /><span className="text-accent underline decoration-accent/20">Human</span> Connection
              </h2>
              <div className="glass p-8 md:p-12 relative overflow-hidden group border-white/5 bg-white/[0.01] mb-12">
                <p className="text-xl md:text-2xl font-light leading-relaxed text-slate-300 relative z-10" suppressContentEditableWarning contentEditable>
                  Strategy first. I'm a super chill person with humour, but when it comes to work, I take things seriously. I overthink captions. I notice marketing patterns in random places. <span className="text-slate-500">I probably judged your website copy already.</span>
                </p>
              </div>
              <div className="flex flex-wrap gap-8">
                <div className="flex flex-col">
                  <span className="text-2xl font-bold text-white mb-1">01.</span>
                  <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Research Mindset</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-2xl font-bold text-white mb-1">02.</span>
                  <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Creative Edge</span>
                </div>
              </div>
            </RevealText>
          </div>
        </div>
      </section>

      {/* AI Section */}
      <section className="py-40 px-6 md:px-12 lg:px-24">
        <div className="max-w-7xl mx-auto">
          <SectionLabel>Neural Architecture</SectionLabel>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-24 items-center">
            <div className="lg:col-span-2">
              <RevealText>
                <h2 className="text-4xl md:text-8xl font-black tracking-tighter text-white uppercase italic leading-[0.8] mb-12">
                  Human Eye.<br /><span className="text-accent underline decoration-accent/20">Machine</span> Scale.
                </h2>
              </RevealText>
              <div className="glass p-8 md:p-16 border-white/5 bg-white/[0.01] relative overflow-hidden group">
                <div className="absolute top-0 left-0 w-full h-full glitch-overlay opacity-10 pointer-events-none" />
                <p className="text-2xl md:text-4xl font-light tracking-tight mb-12 leading-relaxed text-slate-300 italic" suppressContentEditableWarning contentEditable>
                  "AI is a tool, not a replacement. I use it to scale efficiency, not to replace thinking. Human nuance is the engine."
                </p>
                <div className="flex items-center gap-6">
                  <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center border border-accent/20">
                    <Cpu className="text-accent" size={24} />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] uppercase tracking-widest text-accent font-black" suppressContentEditableWarning contentEditable>Augmented Writing</span>
                    <span className="text-[10px] text-slate-600 uppercase tracking-widest font-mono">Build v2.4</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="hidden lg:flex flex-col gap-12">
               {[
                 { label: "Efficiency", val: "300%" },
                 { label: "Precision", val: "99.9%" },
                 { label: "Nuance", val: "Human" }
               ].map((stat, i) => (
                 <motion.div 
                   key={i} 
                   initial={{ opacity: 0, x: 20 }}
                   whileInView={{ opacity: 1, x: 0 }}
                   transition={{ delay: i * 0.1 }}
                   className="border-b border-white/5 pb-8"
                 >
                   <span className="text-6xl font-black text-white block mb-2">{stat.val}</span>
                   <span className="text-[10px] uppercase tracking-[0.4em] text-slate-600 font-bold">{stat.label}</span>
                 </motion.div>
               ))}
            </div>
          </div>
        </div>
      </section>

      {/* Tools Grid */}
      <section className="py-40 px-6 md:px-12 lg:px-24 border-t border-white/5 relative bg-white/[0.01]">
        <div className="max-w-7xl mx-auto">
          <SectionLabel>Technology Stack</SectionLabel>
          <div className="grid grid-cols-2 lg:grid-cols-6 gap-px bg-white/10 border border-white/10">
            {['Strategy', 'SEO & AEO', 'Creative', 'Analysis', 'Editorial', 'Scale'].map((tool, i) => (
              <div key={i} className="bg-bg-dark h-[200px] flex flex-col items-center justify-center text-center hover:bg-accent transition-all duration-500 group cursor-default p-8">
                <span className="text-[10px] font-mono font-black tracking-[0.4em] text-slate-600 group-hover:text-bg-dark transition-colors uppercase mb-4">Stack_{i+1}</span>
                <span className="text-sm font-black tracking-widest text-slate-400 group-hover:text-bg-dark transition-colors uppercase" suppressContentEditableWarning contentEditable>{tool}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Reflections */}
      <section className="py-40 px-6 md:px-12 lg:px-24 border-t border-white/5 bg-white/[0.02]">
        <div className="max-w-7xl mx-auto">
          <SectionLabel>Internal Observations</SectionLabel>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 mb-24">
            <RevealText>
              <h2 className="text-5xl md:text-8xl font-black tracking-tighter text-white uppercase leading-[0.8]">
                Through My<br />Lens
              </h2>
            </RevealText>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              "Some brands need better strategy. Others just need punctuation.",
              "Half of marketing is psychology. The other half is timing.",
              "People don't hate ads. They hate boring ads.",
              "Good copy doesn't explain. It makes you feel something.",
              "If your brand sounds like everyone else, why should anyone care?",
              "Marketing isn't magic. It's just understanding people better than they understand themselves."
            ].map((quote, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: i * 0.1 }}
                className="bg-bg-dark border border-white/5 p-12 h-full relative group hover:border-accent transition-all duration-500 overflow-hidden"
              >
                {/* Camera UI Elements */}
                <div className="absolute top-6 left-6 flex items-center gap-2 opacity-20 group-hover:opacity-60 transition-opacity">
                  <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  <span className="text-[8px] font-mono tracking-tighter text-white">REC</span>
                </div>
                
                <div className="absolute top-6 right-6 flex items-center gap-1 opacity-20 group-hover:opacity-60 transition-opacity font-mono text-[8px]">
                  <Battery className="w-3 h-3 text-emerald-400" />
                  <span className="text-white">POWER_88%</span>
                </div>

                <div className="absolute bottom-6 left-6 opacity-20 group-hover:opacity-60 transition-opacity font-mono text-[8px] text-slate-500">
                  <span>2026/05/09 19:11</span>
                </div>

                <div className="absolute bottom-6 right-6 opacity-20 group-hover:opacity-60 transition-opacity">
                  <Maximize className="w-3 h-3 text-accent" />
                </div>

                {/* Corner Brackets */}
                <div className="absolute top-4 left-4 w-4 h-4 border-t border-l border-white/10 group-hover:border-accent/30" />
                <div className="absolute top-4 right-4 w-4 h-4 border-t border-r border-white/10 group-hover:border-accent/30" />
                <div className="absolute bottom-4 left-4 w-4 h-4 border-b border-l border-white/10 group-hover:border-accent/30" />
                <div className="absolute bottom-4 right-4 w-4 h-4 border-b border-r border-white/10 group-hover:border-accent/30" />

                <div className="relative z-10 flex flex-col justify-center h-full pt-8 pb-8 min-h-[160px]">
                  <p className="text-xl md:text-2xl leading-relaxed text-slate-300 font-light" suppressContentEditableWarning contentEditable>"{quote}"</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Selected Work Section */}
      <section className="py-40 px-6 md:px-12 lg:px-24 border-t border-white/5 bg-white/[0.01]">
        <div className="max-w-7xl mx-auto">
          <SectionLabel>Portfolio</SectionLabel>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-px bg-white/10 border border-white/10">
            {[
              { 
                title: "AI Strategy Framework", 
                desc: "A deep dive into leveraging artificial intelligence for scalable content creation.",
                tag: "Strategy",
                link: "https://docs.google.com/document/d/1Wp5r0UPVoERO34G2YHhd1ICiqAUWH_nh0rUbcPoEwBI/edit?usp=sharing"
              },
              { 
                title: "Editorial Showcase", 
                desc: "Human-centric storytelling with precision and original editorial direction.",
                tag: "Editorial",
                link: "https://docs.google.com/document/d/1FYW0_TrqUE9JsmDNjr5XD0oc3wGVi2nI1OplqgImtBQ/edit?usp=sharing"
              }
            ].map((work, i) => (
              <motion.a 
                key={i}
                href={work.link}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-bg-dark p-12 md:p-24 group hover:bg-white/[0.03] transition-all duration-700 relative overflow-hidden h-full block"
              >
                <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-4">
                    <span className="text-[10px] font-mono font-black tracking-[0.3em] uppercase text-accent/60 group-hover:text-accent group-hover:tracking-[0.5em] transition-all">
                      {work.tag}
                    </span>
                    <div className="flex-1 h-px bg-white/5" />
                  </div>
                  <h3 className="text-4xl md:text-6xl font-black text-white mb-6 tracking-tighter uppercase group-hover:italic transition-all">
                    {work.title}
                  </h3>
                  <p className="text-slate-500 text-lg md:text-xl font-light leading-relaxed max-w-md group-hover:text-slate-300 transition-colors mb-8">
                    {work.desc}
                  </p>
                  
                  <div className="flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.3em] text-accent/40 group-hover:text-accent group-hover:translate-x-2 transition-all">
                    <span>Click here to check my work →</span>
                  </div>
                </div>
                <div className="absolute top-0 right-0 w-64 h-64 bg-accent/5 rounded-full blur-[100px] translate-x-1/2 -translate-y-1/2 group-hover:bg-accent/10 transition-all duration-1000" />
              </motion.a>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-40 px-6 md:px-12 lg:px-24 border-t border-white/5 relative bg-white/[0.02]">
        <div className="max-w-7xl mx-auto">
          <SectionLabel>Process & Architecture</SectionLabel>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 mb-32">
            <RevealText>
              <h2 className="text-5xl md:text-8xl font-black tracking-tighter text-white uppercase leading-[0.8]">
                How we<br />Scale
              </h2>
            </RevealText>
            <div className="flex flex-col justify-end">
              <RevealText>
                <p className="text-xl md:text-2xl text-slate-400 font-light leading-relaxed max-w-md">
                  A systematic approach to brand storytelling and technical execution that ensures every pixel and word serves a purpose.
                </p>
              </RevealText>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-white/10 border border-white/10">
            {[
              { id: "01", title: "Discovery", desc: "Before writing a single word, I research your industry, competitors, audience behaviour, and what actually works. Data first, creativity second." },
              { id: "02", title: "Architecture", desc: "What's the goal? Who's reading? What action do we want? I map out the message, tone, structure, and SEO & AEO approach before execution." },
              { id: "03", title: "Engineering", desc: "I write, edit, rewrite. The first draft is never the final draft. Every sentence is intentional. Every word earns its place." },
              { id: "04", title: "Deployment", desc: "SEO & AEO metadata, schema markup, readability checks, tone consistency. Your content is delivered ready to publish, not ready to fix." }
            ].map((step, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 1, delay: i * 0.1 }}
                className="bg-bg-dark p-12 md:p-20 group hover:bg-white/[0.03] transition-colors relative h-full"
              >
                <span className="text-[10vw] md:text-[6vw] font-black text-white/5 absolute top-0 left-8 select-none pointer-events-none group-hover:text-accent/10 transition-colors">
                  {step.id}
                </span>
                <div className="relative z-10 pt-12">
                  <h3 className="text-3xl font-bold mb-6 text-white tracking-tight uppercase" suppressContentEditableWarning contentEditable>{step.title}</h3>
                  <p className="text-slate-500 leading-relaxed max-w-sm" suppressContentEditableWarning contentEditable>{step.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-64 px-6 text-center relative overflow-hidden">
        <div className="absolute inset-0 glitch-overlay opacity-20" />
        <div className="max-w-5xl mx-auto relative z-10">
          <RevealText>
            <span className="text-[10px] font-mono tracking-[0.5em] uppercase text-accent mb-12 block">Transmission_End</span>
            <h2 className="font-sans text-[12vw] lg:text-[10vw] font-black tracking-[-0.05em] mb-16 text-white uppercase leading-none">
              Start the<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent via-accent-purple to-cyan-400">Dialogue.</span>
            </h2>
          </RevealText>
          
          <div className="flex flex-col items-center gap-12">
            <div className="flex flex-wrap justify-center gap-12">
              <motion.button 
                whileHover={{ scale: 1.1, rotate: -2 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setShowEmail(!showEmail)}
                className="px-16 py-8 bg-white text-bg-dark text-[10px] uppercase tracking-[0.4em] font-black rounded-full shadow-2xl hover:bg-accent transition-all cursor-pointer"
              >
                {showEmail ? 'Close Signal' : 'Initiate Email'}
              </motion.button>
              <motion.a 
                whileHover={{ scale: 1.1, rotate: 2 }}
                whileTap={{ scale: 0.9 }}
                href="https://www.linkedin.com/in/ujala-nawab001/" 
                target="_blank"
                rel="noopener noreferrer"
                className="px-16 py-8 glass text-white text-[10px] uppercase tracking-[0.4em] font-black border border-white/20 rounded-full hover:bg-white/5 transition-all flex items-center"
              >
                LinkedIn
              </motion.a>
            </div>

            <AnimatePresence>
              {showEmail && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.8, y: 40 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8, y: 40 }}
                  className="glass p-8 md:p-12 flex flex-col md:flex-row items-center gap-12 backdrop-blur-3xl border-white/10"
                >
                  <div className="text-left">
                    <span className="text-[10px] font-mono tracking-widest text-accent mb-2 block">DIRECT_OUTPUT</span>
                    <span className="text-2xl md:text-3xl font-black text-white tracking-tight">ujalanawab530@gmail.com</span>
                  </div>
                  <div className="flex gap-4">
                    <button 
                      onClick={handleCopy}
                      className="p-6 bg-white/5 hover:bg-accent hover:text-bg-dark rounded-full transition-all"
                    >
                      {copied ? <Check size={24} /> : <Copy size={24} />}
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* Modern Minimalist Footer */}
      <footer className="py-20 px-6 md:px-12 lg:px-24 border-t border-white/5 text-center bg-white/[0.01]">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-4">
            <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
            <span className="text-[10px] font-mono tracking-[0.4em] text-slate-500 uppercase">System Active | MMXXVI</span>
          </div>
          <p className="text-[10px] font-mono tracking-[0.4em] text-slate-600 uppercase">
            © Ujala Nawab Portfolio
          </p>
          <div className="flex gap-8">
            {['Behance'].map((link, i) => (
              <span key={i} className="text-[10px] font-mono tracking-[0.2em] text-slate-500 uppercase hover:text-white cursor-pointer transition-colors">{link}</span>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
